// Show settings page
export function showSettings() {
  $(".menu-button").hide();
  $("#loading-bar").show();

  $(".input").hide();
  $("#name-input").show();

  $(".tab-container").hide();
  $("#settings").show();
  $("#video-button")[0].click();
}
