# BlockCraft

BlockCraft is a WebGL implementation of an infinite procedurally-generated voxel world that runs on the browser. This project originally spawned as a Minecraft Classic clone but has expanded to include multiplayer PvP, crafting, shaders and much more!

Here's a [summary](https://victorwei.com/blog/blockcraft.pdf) of my development journey!

Currently, this repo is no longer maintained and support will no longer be provided.

## [Play it online now](https://miniblox.io)
